const API_KEY = 'AIzaSyCLhsVtH-JNMQgSWF94yfc0lqUuw_fnsTM';

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "fetchYTInfo",
    title: "查詢此 YouTube 頻道資訊",
    contexts: ["page"]
  });
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === "fetchYTInfo") {
    if (!tab || !tab.url || !tab.url.includes('youtube.com')) {
      return;
    }

    // 執行腳本抓取頻道識別碼
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: extractChannelInfoFromPage
    }, async (results) => {
      if (!results || !results[0] || !results[0].result) {
        chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: () => alert('無法識別此 YouTube 頻道')
        });
        return;
      }

      const identifier = results[0].result;
      
      // 直接透過 background 呼叫 API 取得數據並用 alert 顯示
      try {
        let apiUrl = '';
        if (identifier.type === 'forHandle') {
          apiUrl = `https://www.googleapis.com/youtube/v3/channels?part=snippet,statistics&forHandle=${identifier.value}&key=${API_KEY}`;
        } else if (identifier.type === 'id') {
          apiUrl = `https://www.googleapis.com/youtube/v3/channels?part=snippet,statistics&id=${identifier.value}&key=${API_KEY}`;
        }

        const response = await fetch(apiUrl);
        const data = await response.json();

        if (data.items && data.items.length > 0) {
          const channel = data.items[0];
          const name = channel.snippet.title;
          const subs = Number(channel.statistics.subscriberCount).toLocaleString();
          const videos = Number(channel.statistics.videoCount).toLocaleString();

          // 彈窗顯示結果
          chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: (n, s, v) => alert(`【頻道資訊】\n名稱：${n}\n訂閱人數：${s}\n公開影片：${v}`),
            args: [name, subs, videos]
          });
        } else {
          chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: () => alert('找不到該頻道的 API 資料')
          });
        }
      } catch (error) {
        console.error(error);
      }
    });
  }
});

function extractChannelInfoFromPage() {
  const url = window.location.href;
  
  const handleMatch = url.match(/youtube\.com\/@([^\/?#]+)/);
  if (handleMatch) {
    // 解碼中文 handle 亂碼
    return { type: 'forHandle', value: decodeURIComponent(handleMatch[1]) };
  }

  const channelMatch = url.match(/youtube\.com\/channel\/(UC[^\/?#]+)/);
  if (channelMatch) return { type: 'id', value: channelMatch[1] };

  const channelLink = document.querySelector('ytd-channel-name a, #upload-info #channel-name a');
  if (channelLink && channelLink.href) {
    const href = channelLink.href;
    const matchHandle = href.match(/@([^\/?#]+)/);
    if (matchHandle) return { type: 'forHandle', value: decodeURIComponent(matchHandle[1]) };
  }

  return null;
}