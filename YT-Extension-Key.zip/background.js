chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' || changeInfo.url) {
    broadcastYouTubeStatus();
  }
});

chrome.tabs.onRemoved.addListener(() => {
  broadcastYouTubeStatus();
});

async function broadcastYouTubeStatus() {
  const { active } = await hasActiveYouTubeTabs();
  const tabs = await chrome.tabs.query({});
  for (const t of tabs) {
    if (t.id && t.url && !t.url.startsWith('chrome://') && !t.url.startsWith('edge://')) {
      chrome.tabs.sendMessage(t.id, { action: 'UPDATE_YT_VISIBILITY', active }).catch(() => {});
    }
  }
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'CHECK_YT_TABS') {
    hasActiveYouTubeTabs().then(sendResponse);
    return true;
  }

  if (request.action === 'GET_YT_ACTIVE_INFO') {
    getActiveYouTubePageInfo().then(sendResponse);
    return true;
  }
});

async function hasActiveYouTubeTabs() {
  const tabs = await chrome.tabs.query({});
  const hasYt = tabs.some(t => t.url && t.url.includes('youtube.com') && !t.url.includes('music.youtube.com'));
  return { active: hasYt };
}

async function getActiveYouTubePageInfo() {
  const tabs = await chrome.tabs.query({});
  const ytTab = tabs.find(t => t.url && t.url.includes('youtube.com') && !t.url.includes('music.youtube.com'));

  if (!ytTab) return null;

  try {
    const [res] = await chrome.scripting.executeScript({
      target: { tabId: ytTab.id },
      func: () => {
        const url = window.location.href;
        let videoId = null;

        const vMatch = url.match(/[?&]v=([^&#]+)/);
        if (vMatch) {
          videoId = vMatch[1];
        }

        let identifier = null;
        const handleMatch = url.match(/youtube\.com\/@([^\/?#]+)/);
        if (handleMatch) {
          identifier = { type: 'forHandle', value: decodeURIComponent(handleMatch[1]) };
        }

        const channelMatch = url.match(/youtube\.com\/channel\/(UC[^\/?#]+)/);
        if (channelMatch) {
          identifier = { type: 'id', value: channelMatch[1] };
        }

        const channelLink = document.querySelector('ytd-channel-name a, #upload-info #channel-name a');
        if (!identifier && channelLink && channelLink.href) {
          const matchHandle = channelLink.href.match(/@([^\/?#]+)/);
          if (matchHandle) {
            identifier = { type: 'forHandle', value: decodeURIComponent(matchHandle[1]) };
          }
        }

        return { videoId, identifier };
      }
    });

    return res ? res.result : null;
  } catch (err) {
    return null;
  }
}