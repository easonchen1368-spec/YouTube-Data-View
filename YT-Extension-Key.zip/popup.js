const API_KEY = 'AIzaSyCLhsVtH-JNMQgSWF94yfc0lqUuw_fnsTM';

document.getElementById('fetchBtn').addEventListener('click', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  
  if (!tab || !tab.url || !tab.url.includes('youtube.com')) {
    alert('請在 YouTube 頻道頁面使用此功能！');
    return;
  }

  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: extractChannelInfoFromPage
  }, async (results) => {
    if (!results || !results[0] || !results[0].result) {
      alert('無法識別此 YouTube 頻道，請確認您在頻道首頁或影片頁面。');
      return;
    }

    const channelIdentifier = results[0].result;
    await fetchChannelData(channelIdentifier);
  });
});

function extractChannelInfoFromPage() {
  const url = window.location.href;
  
  const handleMatch = url.match(/youtube\.com\/@([^\/?#]+)/);
  if (handleMatch) return { type: 'forHandle', value: decodeURIComponent(handleMatch[1]) };

  const channelMatch = url.match(/youtube\.com\/channel\/(UC[^\/?#]+)/);
  if (channelMatch) return { type: 'id', value: channelMatch[1] };

  const channelLink = document.querySelector('ytd-channel-name a, #upload-info #channel-name a');
  if (channelLink && channelLink.href) {
    const href = channelLink.href;
    const matchHandle = href.match(/@([^\/?#]+)/);
    if (matchHandle) return { type: 'forHandle', value: decodeURIComponent(matchHandle[1]) };
  }

  return null;
}

async function fetchChannelData(identifier) {
  let apiUrl = '';
  if (identifier.type === 'forHandle') {
    apiUrl = `https://www.googleapis.com/youtube/v3/channels?part=snippet,statistics&forHandle=${identifier.value}&key=${API_KEY}`;
  } else if (identifier.type === 'id') {
    apiUrl = `https://www.googleapis.com/youtube/v3/channels?part=snippet,statistics&id=${identifier.value}&key=${API_KEY}`;
  }

  try {
    const response = await fetch(apiUrl);
    const data = await response.json();

    if (data.items && data.items.length > 0) {
      const channel = data.items[0];
      document.getElementById('chanName').textContent = channel.snippet.title;
      document.getElementById('chanSubs').textContent = Number(channel.statistics.subscriberCount).toLocaleString();
      document.getElementById('chanVideos').textContent = Number(channel.statistics.videoCount).toLocaleString();
      document.getElementById('result').style.display = 'block';
    } else {
      alert('找不到該頻道的 API 資料');
    }
  } catch (error) {
    console.error(error);
    alert('連線至 YouTube API 失敗');
  }
}