const DEFAULT_API_KEY = 'AIzaSyCLhsVtH-JNMQgSWF94yfc0lqUuw_fnsTM';

let cachedIdentifier = '';
let cachedData = null;
let currentEmbeddedVideoId = '';
let isConfigMode = false;
let isPinned = false;

// 拖曳與 2 秒延遲判定狀態
let isDragging = false;
let dragStartX = 0;
let dragStartY = 0;
let initialLeft = 0;
let initialTop = 0;
let hasMoved = false;
let hoverTimer = null;

function isExtensionValid() {
  return typeof chrome !== 'undefined' && chrome.runtime && !!chrome.runtime.id;
}

function initFloatingWidget() {
  if (document.getElementById('yt-floating-widget')) return;

  let logoUrl = '';
  try {
    if (isExtensionValid()) {
      logoUrl = chrome.runtime.getURL('logo.jpg');
    }
  } catch (e) {
    return;
  }

  const container = document.createElement('div');
  container.id = 'yt-floating-widget';
  container.className = 'dock-right';

  container.innerHTML = `
    <div id="yt-floating-btn" title="拖曳可移動 / 停留2秒展開 / 點擊鎖定">
      <img src="${logoUrl}" alt="logo" onerror="this.parentElement.innerHTML='▶'">
    </div>
    <div id="yt-info-card">
      <div class="yt-card-header">
        <div class="yt-card-header-left">
          <img src="${logoUrl}" alt="logo" onerror="this.style.display='none'">
          <h4>YouTube 快速查看器</h4>
        </div>
        <div class="yt-card-header-right">
          <span class="yt-pin-badge">已鎖定</span>
          <button id="yt-toggle-settings-btn" class="yt-settings-icon-btn" title="自訂 API Key 設定">⚙️</button>
        </div>
      </div>

      <div id="yt-player-box" class="yt-player-container" style="display: none;"></div>

      <div id="yt-card-content">
        <p style="color:#666; font-size:13px; margin: 10px 0;">載入資訊中...</p>
      </div>
    </div>
  `;

  document.body.appendChild(container);

  loadSavedPosition();
  setupDraggableWidget();

  // 1. 滑鼠停留 ≥ 2 秒才展開面板
  container.addEventListener('mouseenter', () => {
    if (isDragging || isPinned) return;
    
    hoverTimer = setTimeout(() => {
      container.classList.add('is-card-open');
      if (!isConfigMode) {
        handleMouseEnter();
      }
    }, 2000); // 2000 毫秒 (2 秒)
  });

  // 滑鼠移開時取消計時並縮小面板
  container.addEventListener('mouseleave', () => {
    if (hoverTimer) {
      clearTimeout(hoverTimer);
      hoverTimer = null;
    }
    if (!isPinned) {
      container.classList.remove('is-card-open');
    }
  });

  // 2. 鍵盤按 ESC 鍵立即解鎖並收合
  window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' || e.keyCode === 27) {
      if (hoverTimer) clearTimeout(hoverTimer);
      isPinned = false;
      container.classList.remove('is-card-open');
      updatePinnedState();
    }
  });

  // 3. 設定按鈕切換
  document.getElementById('yt-toggle-settings-btn').addEventListener('click', (e) => {
    e.stopPropagation();
    isConfigMode = !isConfigMode;
    if (isConfigMode) {
      renderApiKeySetup(false);
    } else {
      handleMouseEnter();
    }
  });

  // 4. 監聽影片播放結束訊息
  window.addEventListener('message', (event) => {
    try {
      if (typeof event.data === 'string') {
        const msg = JSON.parse(event.data);
        if (msg.event === 'infoDelivery' && msg.info === 0) {
          isPinned = false;
          container.classList.remove('is-card-open');
          updatePinnedState();
        }
      }
    } catch (err) {}
  });

  if (isExtensionValid()) {
    chrome.runtime.onMessage.addListener((msg) => {
      if (msg.action === 'UPDATE_YT_VISIBILITY') {
        applyVisibility(msg.active);
      }
    });
  }

  checkAndToggleVisibility();
}

function setupDraggableWidget() {
  const container = document.getElementById('yt-floating-widget');
  const btn = document.getElementById('yt-floating-btn');

  btn.addEventListener('mousedown', (e) => {
    if (e.button !== 0) return;
    e.preventDefault();

    // 開始拖動時取消展開計時
    if (hoverTimer) {
      clearTimeout(hoverTimer);
      hoverTimer = null;
    }

    isDragging = true;
    hasMoved = false;
    dragStartX = e.clientX;
    dragStartY = e.clientY;

    const rect = container.getBoundingClientRect();
    initialLeft = rect.left;
    initialTop = rect.top;

    container.classList.remove('animating');
    container.classList.add('is-dragging');

    document.addEventListener('mousemove', onMouseMove);
    document.addEventListener('mouseup', onMouseUp);
  });

  function onMouseMove(e) {
    if (!isDragging) return;

    const dx = e.clientX - dragStartX;
    const dy = e.clientY - dragStartY;

    if (Math.abs(dx) > 4 || Math.abs(dy) > 4) {
      hasMoved = true;
    }

    let newLeft = initialLeft + dx;
    let newTop = initialTop + dy;

    const maxLeft = window.innerWidth - container.offsetWidth;
    const maxTop = window.innerHeight - container.offsetHeight;

    newLeft = Math.max(8, Math.min(newLeft, maxLeft - 8));
    newTop = Math.max(16, Math.min(newTop, maxTop - 16));

    container.style.left = `${newLeft}px`;
    container.style.top = `${newTop}px`;
    container.style.right = 'auto';
  }

  function onMouseUp(e) {
    if (!isDragging) return;
    isDragging = false;
    container.classList.remove('is-dragging');

    document.removeEventListener('mousemove', onMouseMove);
    document.removeEventListener('mouseup', onMouseUp);

    // 未位移則視為點擊鎖定
    if (!hasMoved) {
      isPinned = !isPinned;
      updatePinnedState();
      if (isPinned) {
        container.classList.add('is-card-open');
        handleMouseEnter();
      } else {
        container.classList.remove('is-card-open');
      }
      return;
    }

    // 啟動 iOS Q 彈自動邊緣吸附
    snapToNearestEdge();
  }
}

function snapToNearestEdge() {
  const container = document.getElementById('yt-floating-widget');
  const rect = container.getBoundingClientRect();
  const screenWidth = window.innerWidth;
  const screenHeight = window.innerHeight;

  const snapMargin = 16;
  let targetLeft = snapMargin;
  let dockSide = 'dock-left';

  if (rect.left + rect.width / 2 >= screenWidth / 2) {
    targetLeft = screenWidth - rect.width - snapMargin;
    dockSide = 'dock-right';
  }

  let targetTop = Math.max(20, Math.min(rect.top, screenHeight - rect.height - 20));

  container.className = `animating ${dockSide} ${isPinned ? 'is-pinned' : ''} ${container.classList.contains('is-card-open') ? 'is-card-open' : ''}`;
  container.style.left = `${targetLeft}px`;
  container.style.top = `${targetTop}px`;

  try {
    localStorage.setItem('yt_widget_pos', JSON.stringify({
      dockSide,
      topPercent: (targetTop / screenHeight) * 100
    }));
  } catch (e) {}

  setTimeout(() => {
    container.classList.remove('animating');
  }, 450);
}

function loadSavedPosition() {
  const container = document.getElementById('yt-floating-widget');
  try {
    const saved = localStorage.getItem('yt_widget_pos');
    if (saved) {
      const { dockSide, topPercent } = JSON.parse(saved);
      const screenHeight = window.innerHeight;
      const screenWidth = window.innerWidth;
      const targetTop = (topPercent / 100) * screenHeight;

      container.className = dockSide;
      container.style.top = `${targetTop}px`;

      if (dockSide === 'dock-left') {
        container.style.left = '16px';
        container.style.right = 'auto';
      } else {
        container.style.left = `${screenWidth - 50 - 16}px`;
        container.style.right = 'auto';
      }
      return;
    }
  } catch (e) {}

  container.className = 'dock-right';
  container.style.top = '50%';
  container.style.left = `${window.innerWidth - 50 - 16}px`;
}

function updatePinnedState() {
  const widget = document.getElementById('yt-floating-widget');
  if (widget) {
    if (isPinned) {
      widget.classList.add('is-pinned');
    } else {
      widget.classList.remove('is-pinned');
    }
  }
}

function applyVisibility(show) {
  const widget = document.getElementById('yt-floating-widget');
  if (widget) {
    widget.style.display = show ? 'flex' : 'none';
  }
}

function checkAndToggleVisibility() {
  if (!isExtensionValid()) return;
  try {
    chrome.runtime.sendMessage({ action: 'CHECK_YT_TABS' }, (res) => {
      if (chrome.runtime.lastError) return;
      if (res && typeof res.active === 'boolean') {
        applyVisibility(res.active);
      }
    });
  } catch (err) {}
}

function getActiveApiKey() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['yt_custom_api_key'], (result) => {
      const customKey = result.yt_custom_api_key;
      if (customKey && customKey.trim() !== '') {
        resolve({ key: customKey.trim(), isCustom: true });
      } else {
        resolve({ key: DEFAULT_API_KEY, isCustom: false });
      }
    });
  });
}

async function renderApiKeySetup(isQuotaExceeded = false) {
  const { key, isCustom } = await getActiveApiKey();
  const content = document.getElementById('yt-card-content');
  const playerBox = document.getElementById('yt-player-box');
  if (playerBox) playerBox.style.display = 'none';

  const alertHeader = isQuotaExceeded
    ? `<div style="color:#e65100; font-weight:bold; margin-bottom:6px;">⚠️ 預設 API 配額已用盡</div>
       <p style="margin:0 0 6px 0; color:#555;">請輸入您個人的 YouTube Data API 金鑰以繼續使用：</p>`
    : `<div style="font-weight:bold; margin-bottom:6px;">⚙️ API Key 管理</div>
       <p style="margin:0 0 6px 0; color:#555;">目前使用：<strong>${isCustom ? '自訂金鑰' : '系統預設金鑰'}</strong></p>`;

  content.innerHTML = `
    <div class="yt-api-setup-box ${isQuotaExceeded ? 'quota-alert' : ''}">
      ${alertHeader}
      <input type="password" id="yt-custom-api-key-input" placeholder="貼上自訂 API Key (AIzaSy...)" value="${isCustom ? key : ''}">
      <div class="yt-api-setup-btn-group">
        <button id="yt-save-api-key-btn" class="yt-save-btn">儲存金鑰</button>
        ${isCustom ? '<button id="yt-clear-api-key-btn" class="yt-clear-btn">重置為預設</button>' : ''}
      </div>
    </div>
  `;

  document.getElementById('yt-save-api-key-btn').onclick = () => {
    const newKey = document.getElementById('yt-custom-api-key-input').value.trim();
    if (!newKey) {
      alert('請輸入有效的 API Key！');
      return;
    }
    chrome.storage.local.set({ yt_custom_api_key: newKey }, () => {
      alert('自訂 API Key 已儲存！');
      isConfigMode = false;
      cachedIdentifier = '';
      cachedData = null;
      handleMouseEnter();
    });
  };

  const clearBtn = document.getElementById('yt-clear-api-key-btn');
  if (clearBtn) {
    clearBtn.onclick = () => {
      chrome.storage.local.remove(['yt_custom_api_key'], () => {
        alert('已恢復為系統預設 API 金鑰！');
        isConfigMode = false;
        cachedIdentifier = '';
        cachedData = null;
        handleMouseEnter();
      });
    };
  }
}

async function handleMouseEnter() {
  if (!isExtensionValid()) return;

  chrome.runtime.sendMessage({ action: 'GET_YT_ACTIVE_INFO' }, async (info) => {
    if (chrome.runtime.lastError || !info) return;

    const { videoId, identifier } = info;
    const { key: apiKey } = await getActiveApiKey();
    const content = document.getElementById('yt-card-content');
    const playerBox = document.getElementById('yt-player-box');

    if (videoId && videoId !== currentEmbeddedVideoId) {
      currentEmbeddedVideoId = videoId;
      playerBox.innerHTML = `
        <iframe src="https://www.youtube.com/embed/${videoId}?autoplay=1&mute=1&enablejsapi=1" allow="autoplay; encrypted-media" allowfullscreen></iframe>
      `;
      playerBox.style.display = 'block';
    } else if (!videoId && !currentEmbeddedVideoId) {
      playerBox.style.display = 'none';
    }

    if (!identifier) {
      if (videoId) {
        content.innerHTML = '<p style="color:#444; font-size:12px; margin: 4px 0;">已載入當前 YouTube 影片！</p>';
      } else {
        content.innerHTML = '<p style="color:#888; font-size:13px;">未能識別頻道或影片</p>';
      }
      return;
    }

    const idKey = identifier.type + ':' + identifier.value;
    if (cachedIdentifier === idKey && cachedData) {
      renderCard(cachedData);
      return;
    }

    try {
      let channelApiUrl = '';
      if (identifier.type === 'forHandle') {
        channelApiUrl = `https://www.googleapis.com/youtube/v3/channels?part=snippet,statistics,contentDetails&forHandle=${identifier.value}&key=${apiKey}`;
      } else if (identifier.type === 'id') {
        channelApiUrl = `https://www.googleapis.com/youtube/v3/channels?part=snippet,statistics,contentDetails&id=${identifier.value}&key=${apiKey}`;
      }

      const channelRes = await fetch(channelApiUrl);
      const channelJson = await channelRes.json();

      if (channelRes.status === 403 || (channelJson.error && channelJson.error.errors?.some(e => e.reason === 'quotaExceeded'))) {
        isConfigMode = true;
        renderApiKeySetup(true);
        return;
      }

      if (!channelJson.items || channelJson.items.length === 0) return;

      const channel = channelJson.items[0];
      const channelId = channel.id;
      const uploadsPlaylistId = channel.contentDetails?.relatedPlaylists?.uploads;

      let latestVideos = [];
      if (uploadsPlaylistId) {
        const playlistApiUrl = `https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&playlistId=${uploadsPlaylistId}&maxResults=2&key=${apiKey}`;
        const playlistRes = await fetch(playlistApiUrl);
        const playlistJson = await playlistRes.json();
        if (playlistJson.items) {
          latestVideos = playlistJson.items.map(item => ({
            title: item.snippet.title,
            videoId: item.snippet.resourceId.videoId,
            thumbnail: item.snippet.thumbnails?.medium?.url || item.snippet.thumbnails?.default?.url
          }));
        }
      }

      if (!videoId && latestVideos.length > 0 && currentEmbeddedVideoId !== latestVideos[0].videoId) {
        currentEmbeddedVideoId = latestVideos[0].videoId;
        playerBox.innerHTML = `
          <iframe src="https://www.youtube.com/embed/${latestVideos[0].videoId}?autoplay=0&enablejsapi=1" allow="autoplay; encrypted-media" allowfullscreen></iframe>
        `;
        playerBox.style.display = 'block';
      }

      const fullData = {
        channelId: channelId,
        name: channel.snippet.title,
        handle: channel.snippet.customUrl || ('@' + identifier.value),
        avatar: channel.snippet.thumbnails?.default?.url || '',
        subs: Number(channel.statistics.subscriberCount).toLocaleString(),
        videos: Number(channel.statistics.videoCount).toLocaleString(),
        views: Number(channel.statistics.viewCount).toLocaleString(),
        createdYear: new Date(channel.snippet.publishedAt).toLocaleDateString('zh-TW', { year: 'numeric', month: '2-digit' }),
        latestVideos: latestVideos
      };

      cachedIdentifier = idKey;
      cachedData = fullData;
      renderCard(fullData);

    } catch (err) {
      console.error(err);
    }
  });
}

function renderCard(data) {
  const content = document.getElementById('yt-card-content');

  let videosHtml = '';
  if (data.latestVideos && data.latestVideos.length > 0) {
    videosHtml = `
      <div class="yt-section-title">最新發布影片（點擊更換播放器）</div>
      <div class="yt-video-list">
        ${data.latestVideos.map(v => `
          <div class="yt-video-item" style="cursor: pointer;" data-vid="${v.videoId}">
            <img src="${v.thumbnail}" class="yt-video-thumb" alt="thumb">
            <div class="yt-video-info">
              <p class="yt-video-title">${v.title}</p>
            </div>
          </div>
        `).join('')}
      </div>
    `;
  }

  content.innerHTML = `
    <div class="yt-profile-section">
      <img src="${data.avatar}" class="yt-profile-avatar" alt="avatar">
      <div class="yt-profile-details">
        <p class="yt-profile-name" title="${data.name}">${data.name}</p>
        <p class="yt-profile-handle">${data.handle}</p>
      </div>
    </div>

    <div class="yt-stats-grid">
      <div class="yt-stat-item">
        <span class="yt-stat-label">訂閱人數</span>
        <span class="yt-stat-value">${data.subs}</span>
      </div>
      <div class="yt-stat-item">
        <span class="yt-stat-label">公開影片</span>
        <span class="yt-stat-value">${data.videos} 部</span>
      </div>
      <div class="yt-stat-item">
        <span class="yt-stat-label">總觀看次數</span>
        <span class="yt-stat-value">${data.views}</span>
      </div>
      <div class="yt-stat-item">
        <span class="yt-stat-label">創立時間</span>
        <span class="yt-stat-value">${data.createdYear}</span>
      </div>
    </div>

    ${videosHtml}

    <div class="yt-action-buttons">
      <button id="copyChannelIdBtn" class="yt-action-btn">複製 ID</button>
      <a href="https://socialblade.com/youtube/channel/${data.channelId}" target="_blank" class="yt-action-btn socialblade">SocialBlade</a>
    </div>
  `;

  document.querySelectorAll('.yt-video-item').forEach(el => {
    el.onclick = () => {
      const vid = el.getAttribute('data-vid');
      const playerBox = document.getElementById('yt-player-box');
      if (vid && playerBox) {
        currentEmbeddedVideoId = vid;
        playerBox.innerHTML = `
          <iframe src="https://www.youtube.com/embed/${vid}?autoplay=1&enablejsapi=1" allow="autoplay; encrypted-media" allowfullscreen></iframe>
        `;
        playerBox.style.display = 'block';
      }
    };
  });

  const copyBtn = document.getElementById('copyChannelIdBtn');
  if (copyBtn) {
    copyBtn.onclick = () => {
      navigator.clipboard.writeText(data.channelId).then(() => {
        copyBtn.textContent = '已複製！';
        setTimeout(() => { copyBtn.textContent = '複製 ID'; }, 1500);
      });
    };
  }
}

initFloatingWidget();