const API_KEY = 'AIzaSyCLhsVtH-JNMQgSWF94yfc0lqUuw_fnsTM';

let lastUrl = '';
let cachedIdentifier = '';
let cachedData = null;

// 初始化注入懸浮元件
function initFloatingWidget() {
  if (document.getElementById('yt-floating-widget')) return;

  const logoUrl = chrome.runtime.getURL('logo.jpg');

  const container = document.createElement('div');
  container.id = 'yt-floating-widget';

  container.innerHTML = `
    <div id="yt-info-card">
      <div class="yt-card-header">
        <img src="${logoUrl}" alt="logo" onerror="this.style.display='none'">
        <h4>YouTuber 資料快速查看器</h4>
      </div>
      <div id="yt-card-content">
        <p style="color:#666; font-size:13px; margin: 10px 0;">移至此處載入資訊中...</p>
      </div>
    </div>
    <div id="yt-floating-btn" title="YouTuber 資料快速查看器">
      <img src="${logoUrl}" alt="logo" onerror="this.parentElement.innerHTML='▶'">
    </div>
  `;

  document.body.appendChild(container);

  // 滑鼠懸停時觸發載入
  container.addEventListener('mouseenter', handleMouseEnter);
}

// 監聽 YouTube SPA 頁面切換
function observePageNavigation() {
  setInterval(() => {
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      cachedIdentifier = '';
      cachedData = null;
      updateCardLoadingState();
    }
  }, 1000);
}

function updateCardLoadingState() {
  const content = document.getElementById('yt-card-content');
  if (content) {
    content.innerHTML = '<p style="color:#666; font-size:13px; margin: 10px 0;">資料載入中...</p>';
  }
}

async function handleMouseEnter() {
  const identifier = extractChannelInfo();
  const content = document.getElementById('yt-card-content');

  if (!identifier) {
    content.innerHTML = '<p style="color:#888; font-size:13px;">未能識別當前頻道（請至頻道首頁或影片頁）</p>';
    return;
  }

  const idKey = identifier.type + ':' + identifier.value;
  if (cachedIdentifier === idKey && cachedData) {
    renderCard(cachedData);
    return;
  }

  updateCardLoadingState();

  try {
    let channelApiUrl = '';
    if (identifier.type === 'forHandle') {
      channelApiUrl = `https://www.googleapis.com/youtube/v3/channels?part=snippet,statistics,contentDetails&forHandle=${identifier.value}&key=${API_KEY}`;
    } else if (identifier.type === 'id') {
      channelApiUrl = `https://www.googleapis.com/youtube/v3/channels?part=snippet,statistics,contentDetails&id=${identifier.value}&key=${API_KEY}`;
    }

    const channelRes = await fetch(channelApiUrl);
    const channelJson = await channelRes.json();

    if (!channelJson.items || channelJson.items.length === 0) {
      content.innerHTML = '<p style="color:#d32f2f; font-size:13px;">查無此頻道 API 資料</p>';
      return;
    }

    const channel = channelJson.items[0];
    const channelId = channel.id;
    const uploadsPlaylistId = channel.contentDetails?.relatedPlaylists?.uploads;

    // 撈取最新 2 部影片
    let latestVideos = [];
    if (uploadsPlaylistId) {
      const playlistApiUrl = `https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&playlistId=${uploadsPlaylistId}&maxResults=2&key=${API_KEY}`;
      const playlistRes = await fetch(playlistApiUrl);
      const playlistJson = await playlistRes.json();
      if (playlistJson.items) {
        latestVideos = playlistJson.items.map(item => ({
          title: item.snippet.title,
          videoId: item.snippet.resourceId.videoId,
          thumbnail: item.snippet.thumbnails?.medium?.url || item.snippet.thumbnails?.default?.url
        }));
      }
    }

    const fullData = {
      channelId: channelId,
      name: channel.snippet.title,
      handle: channel.snippet.customUrl || ('@' + identifier.value),
      avatar: channel.snippet.thumbnails?.default?.url || '',
      subs: Number(channel.statistics.subscriberCount).toLocaleString(),
      videos: Number(channel.statistics.videoCount).toLocaleString(),
      views: Number(channel.statistics.viewCount).toLocaleString(),
      createdYear: new Date(channel.snippet.publishedAt).toLocaleDateString('zh-TW', { year: 'numeric', month: '2-digit' }),
      latestVideos: latestVideos
    };

    cachedIdentifier = idKey;
    cachedData = fullData;
    renderCard(fullData);

  } catch (err) {
    console.error(err);
    content.innerHTML = '<p style="color:#d32f2f; font-size:13px;">API 連線失敗，請檢查金鑰或網路</p>';
  }
}

function renderCard(data) {
  const content = document.getElementById('yt-card-content');

  let videosHtml = '';
  if (data.latestVideos && data.latestVideos.length > 0) {
    videosHtml = `
      <div class="yt-section-title">最新發布影片</div>
      <div class="yt-video-list">
        ${data.latestVideos.map(v => `
          <a href="https://www.youtube.com/watch?v=${v.videoId}" target="_blank" class="yt-video-item">
            <img src="${v.thumbnail}" class="yt-video-thumb" alt="thumb">
            <div class="yt-video-info">
              <p class="yt-video-title">${v.title}</p>
            </div>
          </a>
        `).join('')}
      </div>
    `;
  }

  content.innerHTML = `
    <div class="yt-profile-section">
      <img src="${data.avatar}" class="yt-profile-avatar" alt="avatar">
      <div class="yt-profile-details">
        <p class="yt-profile-name" title="${data.name}">${data.name}</p>
        <p class="yt-profile-handle">${data.handle}</p>
      </div>
    </div>

    <div class="yt-stats-grid">
      <div class="yt-stat-item">
        <span class="yt-stat-label">訂閱人數</span>
        <span class="yt-stat-value">${data.subs}</span>
      </div>
      <div class="yt-stat-item">
        <span class="yt-stat-label">公開影片</span>
        <span class="yt-stat-value">${data.videos} 部</span>
      </div>
      <div class="yt-stat-item">
        <span class="yt-stat-label">總觀看次數</span>
        <span class="yt-stat-value">${data.views}</span>
      </div>
      <div class="yt-stat-item">
        <span class="yt-stat-label">創立時間</span>
        <span class="yt-stat-value">${data.createdYear}</span>
      </div>
    </div>

    ${videosHtml}

    <div class="yt-action-buttons">
      <button id="copyChannelIdBtn" class="yt-action-btn">複製 ID</button>
      <a href="https://socialblade.com/youtube/channel/${data.channelId}" target="_blank" class="yt-action-btn socialblade">SocialBlade</a>
    </div>
  `;

  // 綁定複製 ID 按鈕
  const copyBtn = document.getElementById('copyChannelIdBtn');
  if (copyBtn) {
    copyBtn.onclick = () => {
      navigator.clipboard.writeText(data.channelId).then(() => {
        copyBtn.textContent = '已複製！';
        setTimeout(() => { copyBtn.textContent = '複製 ID'; }, 1500);
      });
    };
  }
}

function extractChannelInfo() {
  const url = window.location.href;

  const handleMatch = url.match(/youtube\.com\/@([^\/?#]+)/);
  if (handleMatch) {
    return { type: 'forHandle', value: decodeURIComponent(handleMatch[1]) };
  }

  const channelMatch = url.match(/youtube\.com\/channel\/(UC[^\/?#]+)/);
  if (channelMatch) {
    return { type: 'id', value: channelMatch[1] };
  }

  const channelLink = document.querySelector('ytd-channel-name a, #upload-info #channel-name a');
  if (channelLink && channelLink.href) {
    const matchHandle = channelLink.href.match(/@([^\/?#]+)/);
    if (matchHandle) {
      return { type: 'forHandle', value: decodeURIComponent(matchHandle[1]) };
    }
  }

  return null;
}

initFloatingWidget();
observePageNavigation();